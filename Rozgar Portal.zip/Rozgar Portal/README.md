# Job-Portal

The online job portal application allows job seekers and recruiters to connect.The application provides the ability for job seekers to create their accounts, upload their profile and resume, search for jobs, apply for jobs, view different job openings. The application provides the ability for companies to create their accounts, search candidates, create job postings, and view candidates applications.

# View Tutorials

Job Portal (PHP) - Part 1 - Introduction & User Login/Registration - https://youtu.be/3VGxEEpWEaw

Job Portal (PHP) - Part 2 - User Dashboard & Profile Updating - https://youtu.be/VkKXaqFafRA

Job Portal (PHP) - Part-3 - Company Login/Registration & Creating Job Posts - https://youtu.be/OiapxMhgH_I

Job Portal (PHP) - Part 4 - View/Edit/Delete Job Posts - https://youtu.be/E1F-snEgpPs

Job Portal (PHP) - Part 5 - Showing Random Job Post On Homepage & User Applying To Job - https://youtu.be/3qmjqLx3o6o

Job Portal (PHP) - Part 6 - Code Refactor & Bug Fix - https://youtu.be/YVv_JCcVb7s

Job Portal (PHP) - Part 7 - Job Search Page With Advanced Searching Options  - https://youtu.be/wgNd-HgxqJg

Job Portal (PHP) - Part 8 - Generating Resume By Filling Form Using Custom Resume Templates - https://youtu.be/Wndjgmk1SyM

Job Portal (PHP) - Part 9 - Uploading Resume & Company View/Reject User Application - https://youtu.be/SMjiO0UwAoA

Job Portal (PHP) - Part 10 - Admin Panel - https://youtu.be/UdLpBUR2lCs

Job Portal (PHP) - Part 11 - Admin Verifying Company & User Email Verification - https://youtu.be/RwybCIHj0JE

Job Portal (PHP) - Part 12 - Validations & Code Improvements - https://youtu.be/mpO1j16udzM

Job Portal (PHP) - Part 13 - Email Sending Bug Fix - https://youtu.be/5ONR88bt0bY

Job Portal (PHP) - Part 14 - Search Highlighting & Forgot Password - https://youtu.be/HR7tvK5oO1g

Job Portal (PHP) - Part 15 - Select Company Location & Fixed Experience Filter - https://youtu.be/0mDXlpOulWc

Job Portal (PHP) - Part 16 - Theme Update Introduction - https://youtu.be/Lm5I6SSgJAw

Job Portal (PHP) - Part 17 - Homepage, Login & Registration Updated To New Theme - https://youtu.be/6neTJ6QRH6U

Job Portal (PHP) - Part 18 - Company Registration & Login Updated To New Theme - https://youtu.be/WJrQTybFQxo

Job Portal (PHP) - Part 19 - Updated Create Job Post & View Company Job Post - https://youtu.be/PK3Q9aAba-0


# Contact
Feel free to contact me through my website http://learningfromscratch.online/ 
>If you are following this tutorial series I would appritiate if you can subscribe and like my videos as it will keep me motivated to share my knowledge with you all!